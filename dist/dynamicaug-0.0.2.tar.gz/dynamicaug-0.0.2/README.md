# DynamicAugmentation

- Pytorch implementation of very simply applicable Cutout and GridCutOut augmentation
- New torch pipeline of DynamicAugmentation